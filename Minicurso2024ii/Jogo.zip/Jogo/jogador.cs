using Godot;
using System;

public partial class jogador : CharacterBody2D
{
	[Export] private float velocidade = 300.0f; //autoexplicativo
	[Export] private float gravidade = 980.0f; //autoexplicativo
	[Export] private float altura_pulo = -400.0f; //salto é negativo, pois quanto meno o valor de y, mais para cima o personagem vai
	private Vector2 movimento; //combinação de velocidade e direção
	private Vector2 direcao; //direção no eixo x,y. Sendo 0,0 parado e 1,0 indo para direita
	private int vida = 100;
	private bool pulo_duplo;
	[Export] private float acelerar = 200.0f;
	[Export] private float frear = 200.0f;

	[Export] private Timer coiote_tempo;
	private bool estava_chao, deixei_chao;

	/*	O _PhysicsProcess() vai sempre ser executado 60 vezes por segundo.
		Pode-se editar o número em Menu -> Projeto -> Project Settings -> Física -> Comum 
		-> ticks de física por segundo

		Já um _Process() vai executar o máximo de vezes que puder e um segundo */
	
	public override void _PhysicsProcess(double delta) {
		movimento = Velocity; // Copia o movimento atual, para podermos editar

		/*	IsOnFloor() é uma função do CharacterBody2D que retorna verdadeiro (true)
		    quando o jogador está em contato com o chão. 
			Sendo assim, se o jogador não estiver no chão
			A posição y dele irá aumentar, ou seja cair na velocidade presente em GetGravity()
			Para mudar o valor da gravidade basta ir em Menu -> Projeto -> Project Settings -> Física ->
			Física -> 2D -> gravidade
			A única justificativa para usarmos o valor de gravidade do sistema e não um valor direto
			é que não precisaremos entrar em cada código com a variável gravidade 
			para alterarmos isso no nosso jogo.
		*/
		if (IsOnFloor() == false) { 
			movimento.Y += gravidade * (float)delta;
		} 
		
		if (Position.Y > 256) {
			Morreu();
		}

		// Aplica ao eixo Y do movimento a altura_pulo se apertar enter e estiver no chão
		if (IsOnFloor() == true || (float)coiote_tempo.TimeLeft > 0.0f) {
			pulo_duplo = true;
			if (Input.IsActionJustPressed("ui_accept")) {
				movimento.Y = altura_pulo;
				coiote_tempo.Stop();
			}
		} if (IsOnFloor() == false) {
			if (Input.IsActionJustPressed("ui_accept") && pulo_duplo == true) {
				movimento.Y = altura_pulo;
				pulo_duplo = false;
			}
		}
		



		//A função Input.GetVector() facilita o processo de fazer um if para cada direção
		direcao = Input.GetVector("ui_left", "ui_right", "ui_up", "ui_down");
		
		if (direcao != Vector2.Zero) { //se a direção for diferente de zero
			movimento.X = Mathf.MoveToward(Velocity.X, direcao.X * velocidade, acelerar*(float)delta );
			//movimento.X = direcao.X * velocidade;
		}
		else {
			/*Essa função faz o efeito de desaceletar.
			  Para isso são passados respectivamente:
			  velocidade inicial, velocidade final e a velocidade que irá frear.
			  Como a velocidade de inicial e de frear são iguais ele para instantaneamente,
			  sendo assim essa linha de código tem o mesmo efeito que escrever
			  movimento.X = 0; */
			movimento.X = Mathf.MoveToward(Velocity.X, 0, frear*(float)delta);
		}
        
		Velocity = movimento; //substitui o movimento atual pelo editado

		estava_chao = IsOnFloor();
		MoveAndSlide(); //função do CharacterBody2D que aplica os movimentos e a física
		deixei_chao = estava_chao && IsOnFloor() == false;
		if (deixei_chao == true) {
			coiote_tempo.Start();
		}

	
	} //process


	public void Dano (int q) {
		vida = vida - q;
		GD.Print(vida);
		if (vida <= 0) {
			Morreu();
		}
	}

	public bool Vida (int q) {
		if (vida < 100) {
			vida = vida + q;
			return true;
		} else {
			return false;
		}
		
		GD.Print(vida);
	}

	public void Morreu () {
		GD.Print("Morreu!");
		//Position = new Vector2 (24,144);
		GetTree().ChangeSceneToFile("res://mundo.tscn");
	}

} //classe
