using Godot;
using System;

public partial class bloco : StaticBody2D
{
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		if (Input.IsActionPressed("bcima")) {
			Position += new Vector2(0,-1);			
		}
		if (Input.IsActionPressed("bbaixo")) {
			Position += new Vector2(0,1);			
		}
		if (Input.IsActionPressed("besquerda")) {
			Position += new Vector2(-1,0);			
		}
		if (Input.IsActionPressed("bdireita")) {
			Position += new Vector2(1,0);
		}
	}
}
