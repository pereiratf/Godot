using Godot;
using System;

public partial class jogador : CharacterBody2D
{
	private Sprite2D imagem;
	public override void _Ready() {
		imagem = GetNode<Sprite2D>("Sprite2D");
	}

	public override void _Process(double delta)
	{
		if (Input.IsActionPressed("cima")) {
			Position += new Vector2(0,-1);			
		}
		if (Input.IsActionPressed("baixo")) {
			Position += new Vector2(0,1);			
		}
		if (Input.IsActionPressed("esquerda")) {
			Position += new Vector2(-1,0);			
		}
		if (Input.IsActionPressed("direita")) {
			Position += new Vector2(1,0);
		}
		MoveAndSlide();	
	}

	public void MudaCor() {
		GD.Print("mudando de cor");
		imagem.Modulate = new Color(0,1,0);
	}

}
