using Godot;
using System;

public partial class Losango : Area2D
{
	public void Dentro (jogador body) {
		body.MudaCor();
		QueueFree(); //remove do mapa
	}
}
