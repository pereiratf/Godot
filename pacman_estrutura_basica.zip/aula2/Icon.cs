using Godot;
using System;

public partial class Icon : Sprite2D
{
	private Sprite2D filho;
	public override void _Ready()
	{
		filho = GetNode<Sprite2D>("IconFilho");
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		if (Input.IsActionPressed("cima")) {
			Position += new Vector2(0,-128);
			filho.Position = new Vector2(0,128);
		}
		if (Input.IsActionPressed("baixo")) {
			Position += new Vector2(0,128);
			filho.Position = new Vector2(0,-128);
		}
		if (Input.IsActionPressed("esquerda")) {
			Position += new Vector2(-128,0);
			filho.Position = new Vector2(128,0);
		}
		if (Input.IsActionPressed("direita")) {
			Position += new Vector2(128,0);
			filho.Position = new Vector2(-128,0);
		}
	}
}
