using Godot;
using System;

public partial class pilula : Area2D
{
	public void Consumida(jogador j) {
		j.Pilula();
		QueueFree();
		
	}
}
