using Godot;
using System;

public partial class moeda : Area2D
{
	public void Coletada(jogador j) {
		QueueFree();
	}
}
