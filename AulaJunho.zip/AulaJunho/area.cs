using Godot;
using System;

public partial class area : Area2D
{
	
	private CollisionShape2D forma;
	[Export] float x=1, y=1;
	public override void _Ready() {
		forma = GetNode<CollisionShape2D>("CollisionShape2D");
		forma.Shape.Set("size", new Vector2(16*x,16*y));
		GD.Print("entrou");
	}
	[Export] int tipo;
	public void EntrouArea(Jogador j) {
		if (tipo == 1) {
			GD.Print("Morte");
			j.Morte();
		}
		if (tipo == 2) {
			GD.Print("Objetivo");
			j.Renasce();
		}
	}
	
}
